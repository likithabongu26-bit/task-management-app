// auth.js
